package com.example.myjournal

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class JournalEntry(val id: Long,val title:String,val text:String,val mood:String,val date:String,val audioPath:String?=null)

private val JournalPurple=Color(0xFF6C4AB6)
private val JournalLavender=Color(0xFFEDE5FF)
private val JournalCream=Color(0xFFFFFBF5)
private val JournalInk=Color(0xFF27222F)
private val JournalSoft=Color(0xFFF6F1FA)
private val JournalColors=lightColorScheme(primary=JournalPurple,onPrimary=Color.White,primaryContainer=JournalLavender,onPrimaryContainer=JournalInk,background=JournalCream,surface=Color.White,onBackground=JournalInk,onSurface=JournalInk)

class MainActivity:ComponentActivity(){
 private var recorder:MediaRecorder?=null; private var recordingPath:String?=null; private var player:MediaPlayer?=null
 private val permissionLauncher=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
 private fun prefs()=getSharedPreferences("journal",MODE_PRIVATE)
 private fun loadEntries():List<JournalEntry>{val a=JSONArray(prefs().getString("entries","[]"));return List(a.length()){i->val o=a.getJSONObject(i);JournalEntry(o.getLong("id"),o.getString("title"),o.getString("text"),o.getString("mood"),o.getString("date"),if(o.isNull("audioPath"))null else o.getString("audioPath"))}.sortedByDescending{it.id}}
 private fun saveEntries(es:List<JournalEntry>){val a=JSONArray();es.forEach{a.put(JSONObject().apply{put("id",it.id);put("title",it.title);put("text",it.text);put("mood",it.mood);put("date",it.date);put("audioPath",it.audioPath?:JSONObject.NULL)})};prefs().edit().putString("entries",a.toString()).apply()}
 override fun onCreate(b:Bundle?){super.onCreate(b);if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)permissionLauncher.launch(Manifest.permission.RECORD_AUDIO);setContent{MaterialTheme(colorScheme=JournalColors){JournalApp(loadEntries(),{saveEntries(it)},{startRecording()},{stopRecording()},{playAudio(it)})}}}
 private fun startRecording(){val f=File(filesDir,"voice_${System.currentTimeMillis()}.m4a");recordingPath=f.absolutePath;recorder=MediaRecorder(this).apply{setAudioSource(MediaRecorder.AudioSource.MIC);setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);setAudioEncoder(MediaRecorder.AudioEncoder.AAC);setOutputFile(f.absolutePath);prepare();start()}}
 private fun stopRecording():String?{recorder?.runCatching{stop();release()};recorder=null;return recordingPath}
 private fun playAudio(path:String){player?.release();player=MediaPlayer().apply{setDataSource(path);prepare();start();setOnCompletionListener{release();player=null}}}
 override fun onDestroy(){player?.release();recorder?.runCatching{stop();release()};super.onDestroy()}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun JournalApp(initialEntries:List<JournalEntry>,onSaveEntries:(List<JournalEntry>)->Unit,onStartRecording:()->Unit,onStopRecording:()->String?,onPlayAudio:(String)->Unit){
 var entries by remember{mutableStateOf(initialEntries)};var showEditor by remember{mutableStateOf(false)};var editingId by remember{mutableStateOf<Long?>(null)};var query by remember{mutableStateOf("")};var title by remember{mutableStateOf("")};var body by remember{mutableStateOf("")};var mood by remember{mutableStateOf("😊")};var audioPath by remember{mutableStateOf<String?>(null)};var recording by remember{mutableStateOf(false)};var calendarMode by remember{mutableStateOf(false)}
 fun openNew(){editingId=null;title="";body="";mood="😊";audioPath=null;showEditor=true};fun openEdit(e:JournalEntry){editingId=e.id;title=e.title;body=e.text;mood=e.mood;audioPath=e.audioPath;showEditor=true}
 if(showEditor){Scaffold(topBar={TopAppBar(title={Text(if(editingId==null)"New Entry" else "Edit Entry")},navigationIcon={TextButton(onClick={showEditor=false}){Text("Cancel")}})}){pad->Column(Modifier.padding(pad).padding(18.dp).fillMaxSize(),verticalArrangement=Arrangement.spacedBy(12.dp)){OutlinedTextField(title,{title=it},label={Text("Title")},modifier=Modifier.fillMaxWidth());Text("Mood",fontWeight=FontWeight.SemiBold);Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("😊","😐","😔","😡","❤️").forEach{m->FilterChip(mood==m,{mood=m},label={Text(m)})}};OutlinedTextField(body,{body=it},label={Text("Write your thoughts...")},modifier=Modifier.fillMaxWidth().weight(1f));if(audioPath!=null)Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("🎙 Voice recording attached");TextButton(onClick={audioPath?.let(onPlayAudio)}){Text("▶ Play")}};Button(onClick={if(!recording){onStartRecording();recording=true}else{audioPath=onStopRecording();recording=false}},Modifier.fillMaxWidth()){Text(if(recording)"⏹ Stop Recording" else "🎙 Record Voice")};Button(onClick={if(recording){audioPath=onStopRecording();recording=false};val id=editingId?:System.currentTimeMillis();val old=entries.firstOrNull{it.id==id};val e=JournalEntry(id,title.ifBlank{"Untitled"},body,mood,old?.date?:SimpleDateFormat("MMM d, yyyy • h:mm a",Locale.getDefault()).format(Date()),audioPath);entries=(entries.filterNot{it.id==id}+e).sortedByDescending{it.id};onSaveEntries(entries);showEditor=false},Modifier.fillMaxWidth()){Text("Save Entry")}}}}
 else{Scaffold(topBar={TopAppBar(title={Text(if(calendarMode)"Journal Calendar" else "My Journal")},actions={IconButton(onClick={calendarMode=!calendarMode}){Text(if(calendarMode)"☷" else "▦",style=MaterialTheme.typography.titleLarge)}})},floatingActionButton={FloatingActionButton(onClick={openNew()},containerColor=JournalPurple,contentColor=Color.White){Text("+")}}){pad->if(calendarMode)JournalCalendar(entries,{openEdit(it)},Modifier.padding(pad))else Column(Modifier.padding(pad).padding(horizontal=16.dp)){OutlinedTextField(query,{query=it},label={Text("🔍 Search")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(12.dp));val shown=entries.filter{query.isBlank()||it.title.contains(query,true)||it.text.contains(query,true)};if(shown.isEmpty())Text(if(entries.isEmpty())"Your journal is empty.\nTap + to write your first entry." else "No matching entries.")else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(shown,key={it.id}){e->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=JournalSoft)){Column(Modifier.padding(16.dp)){Text("${e.mood}  ${e.title}",style=MaterialTheme.typography.titleLarge);Text(e.date,style=MaterialTheme.typography.bodySmall);Spacer(Modifier.height(5.dp));Text(e.text,maxLines=3);if(e.audioPath!=null)TextButton(onClick={onPlayAudio(e.audioPath)}){Text("▶ Play voice")};Row{TextButton(onClick={openEdit(e)}){Text("Edit")};TextButton(onClick={entries=entries.filterNot{it.id==e.id};onSaveEntries(entries);e.audioPath?.let{File(it).delete()}}){Text("Delete")}}}}}}}}}
}

@Composable fun JournalCalendar(entries:List<JournalEntry>,onEntryClick:(JournalEntry)->Unit,modifier:Modifier=Modifier){
 val today=Calendar.getInstance();var month by remember{mutableStateOf(Calendar.getInstance().apply{set(Calendar.DAY_OF_MONTH,1)})};var selectedDay by remember{mutableStateOf<Calendar?>(Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,12);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)})};val year=month.get(Calendar.YEAR);val mi=month.get(Calendar.MONTH);val monthName=SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(month.time);val first=month.get(Calendar.DAY_OF_WEEK)-1;val days=month.getActualMaximum(Calendar.DAY_OF_MONTH);val byDay=entries.groupBy{val c=Calendar.getInstance().apply{timeInMillis=it.id};Triple(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH))};val selected=selectedDay?.let{byDay[Triple(it.get(Calendar.YEAR),it.get(Calendar.MONTH),it.get(Calendar.DAY_OF_MONTH))].orEmpty()}?:emptyList()
 Column(modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){TextButton(onClick={month=(month.clone() as Calendar).apply{add(Calendar.MONTH,-1);set(Calendar.DAY_OF_MONTH,1)};selectedDay=Calendar.getInstance().apply{timeInMillis=month.timeInMillis;set(Calendar.DAY_OF_MONTH,1);set(Calendar.HOUR_OF_DAY,12);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}}){Text("‹")};Text(monthName,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);TextButton(onClick={month=(month.clone() as Calendar).apply{add(Calendar.MONTH,1);set(Calendar.DAY_OF_MONTH,1)};selectedDay=Calendar.getInstance().apply{timeInMillis=month.timeInMillis;set(Calendar.DAY_OF_MONTH,1);set(Calendar.HOUR_OF_DAY,12);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}}){Text("›")}};Row(Modifier.fillMaxWidth()){listOf("S","M","T","W","T","F","S").forEach{Text(it,Modifier.weight(1f),fontWeight=FontWeight.Bold)}};Column(verticalArrangement=Arrangement.spacedBy(4.dp)){var day=1;var cell=0;while(day<=days){Row(Modifier.fillMaxWidth()){repeat(7){val c=cell++;if(c<first||day>days)Spacer(Modifier.weight(1f).aspectRatio(1f))else{val ds=byDay[Triple(year,mi,day)].orEmpty();val sel=selectedDay?.let{it.get(Calendar.YEAR)==year&&it.get(Calendar.MONTH)==mi&&it.get(Calendar.DAY_OF_MONTH)==day}==true;Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp).background(if(sel)JournalLavender else Color.Transparent,CircleShape).clickable{selectedDay=Calendar.getInstance().apply{set(year,mi,day,12,0,0)}},contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(day.toString(),color=if(sel)JournalPurple else JournalInk,fontWeight=if(ds.isNotEmpty())FontWeight.Bold else FontWeight.Normal);if(ds.isNotEmpty())Box(Modifier.size(5.dp).background(JournalPurple, CircleShape))else Spacer(Modifier.height(5.dp))}};day++}}}}};HorizontalDivider();if(selectedDay==null)Text("Tap a date to see your entries.",color=Color.Gray)else{Text(SimpleDateFormat("EEEE, MMM d",Locale.getDefault()).format(selectedDay!!.time),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);if(selected.isEmpty())Text("No journal entries on this day.",color=Color.Gray)else selected.forEach{e->Card(Modifier.fillMaxWidth().clickable{onEntryClick(e)},colors=CardDefaults.cardColors(containerColor=JournalSoft)){Column(Modifier.padding(14.dp)){Text("${e.mood}  ${e.title}",fontWeight=FontWeight.Bold);Spacer(Modifier.height(4.dp));Text(e.text,maxLines=3)}}}}}
}
