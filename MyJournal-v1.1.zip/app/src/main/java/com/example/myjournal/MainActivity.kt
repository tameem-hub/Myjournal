package com.example.myjournal

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class JournalEntry(
    val id: Long,
    val title: String,
    val text: String,
    val mood: String,
    val date: String,
    val audioPath: String? = null
)

class MainActivity : ComponentActivity() {
    private var recorder: MediaRecorder? = null
    private var recordingPath: String? = null
    private var player: MediaPlayer? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun prefs() = getSharedPreferences("journal", MODE_PRIVATE)

    private fun loadEntries(): List<JournalEntry> {
        val array = JSONArray(prefs().getString("entries", "[]"))
        return List(array.length()) { i ->
            val o = array.getJSONObject(i)
            JournalEntry(
                o.getLong("id"), o.getString("title"), o.getString("text"),
                o.getString("mood"), o.getString("date"),
                if (o.isNull("audioPath")) null else o.getString("audioPath")
            )
        }.sortedByDescending { it.id }
    }

    private fun saveEntries(entries: List<JournalEntry>) {
        val array = JSONArray()
        entries.forEach {
            array.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("text", it.text)
                put("mood", it.mood); put("date", it.date)
                put("audioPath", it.audioPath ?: JSONObject.NULL)
            })
        }
        prefs().edit().putString("entries", array.toString()).apply()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)

        setContent {
            MaterialTheme {
                JournalApp(
                    initialEntries = loadEntries(),
                    onSaveEntries = { saveEntries(it) },
                    onStartRecording = { startRecording() },
                    onStopRecording = { stopRecording() },
                    onPlayAudio = { path -> playAudio(path) }
                )
            }
        }
    }

    private fun startRecording() {
        val file = File(filesDir, "voice_${System.currentTimeMillis()}.m4a")
        recordingPath = file.absolutePath
        recorder = MediaRecorder(this).apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(file.absolutePath)
            prepare(); start()
        }
    }

    private fun stopRecording(): String? {
        recorder?.runCatching { stop(); release() }
        recorder = null
        return recordingPath
    }

    private fun playAudio(path: String) {
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(path)
            prepare()
            start()
            setOnCompletionListener { release(); player = null }
        }
    }

    override fun onDestroy() {
        player?.release()
        recorder?.runCatching { stop(); release() }
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JournalApp(
    initialEntries: List<JournalEntry>,
    onSaveEntries: (List<JournalEntry>) -> Unit,
    onStartRecording: () -> Unit,
    onStopRecording: () -> String?,
    onPlayAudio: (String) -> Unit
) {
    var entries by remember { mutableStateOf(initialEntries) }
    var showEditor by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf<Long?>(null) }
    var query by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("😊") }
    var audioPath by remember { mutableStateOf<String?>(null) }
    var recording by remember { mutableStateOf(false) }

    fun openNew() {
        editingId = null; title = ""; body = ""; mood = "😊"; audioPath = null
        showEditor = true
    }
    fun openEdit(e: JournalEntry) {
        editingId = e.id; title = e.title; body = e.text; mood = e.mood; audioPath = e.audioPath
        showEditor = true
    }

    if (showEditor) {
        Scaffold(topBar = {
            TopAppBar(title = { Text(if (editingId == null) "New Entry" else "Edit Entry") },
                navigationIcon = { TextButton(onClick = { showEditor = false }) { Text("Cancel") } })
        }) { pad ->
            Column(Modifier.padding(pad).padding(18.dp).fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") },
                    modifier = Modifier.fillMaxWidth())
                Text("Mood")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("😊","😐","😔","😡","❤️").forEach { m ->
                        FilterChip(mood == m, { mood = m }, label = { Text(m) })
                    }
                }
                OutlinedTextField(body, { body = it }, label = { Text("Write your thoughts...") },
                    modifier = Modifier.fillMaxWidth().weight(1f))
                if (audioPath != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("🎙 Voice recording attached")
                        TextButton(onClick = { audioPath?.let(onPlayAudio) }) { Text("▶ Play") }
                    }
                }
                Button(onClick = {
                    if (!recording) { onStartRecording(); recording = true }
                    else { audioPath = onStopRecording(); recording = false }
                }, Modifier.fillMaxWidth()) {
                    Text(if (recording) "⏹ Stop Recording" else "🎙 Record Voice")
                }
                Button(onClick = {
                    if (recording) { audioPath = onStopRecording(); recording = false }
                    val id = editingId ?: System.currentTimeMillis()
                    val old = entries.firstOrNull { it.id == id }
                    val entry = JournalEntry(
                        id, title.ifBlank { "Untitled" }, body, mood,
                        old?.date ?: SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()).format(Date()),
                        audioPath
                    )
                    entries = (entries.filterNot { it.id == id } + entry).sortedByDescending { it.id }
                    onSaveEntries(entries)
                    showEditor = false
                }, Modifier.fillMaxWidth()) { Text("Save Entry") }
            }
        }
    } else {
        Scaffold(topBar = {
            TopAppBar(title = { Text("My Journal") })
        }, floatingActionButton = {
            FloatingActionButton(onClick = { openNew() }) { Text("+") }
        }) { pad ->
            Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
                OutlinedTextField(query, { query = it }, label = { Text("🔍 Search") },
                    modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                val shown = entries.filter {
                    query.isBlank() || it.title.contains(query, true) || it.text.contains(query, true)
                }
                if (shown.isEmpty()) {
                    Text(if (entries.isEmpty()) "Your journal is empty.\nTap + to write your first entry."
                         else "No matching entries.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(shown, key = { it.id }) { e ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("${e.mood}  ${e.title}", style = MaterialTheme.typography.titleLarge)
                                    Text(e.date, style = MaterialTheme.typography.bodySmall)
                                    Spacer(Modifier.height(5.dp))
                                    Text(e.text, maxLines = 3)
                                    if (e.audioPath != null) {
                                        TextButton(onClick = { onPlayAudio(e.audioPath) }) { Text("▶ Play voice") }
                                    }
                                    Row {
                                        TextButton(onClick = { openEdit(e) }) { Text("Edit") }
                                        TextButton(onClick = {
                                            entries = entries.filterNot { it.id == e.id }
                                            onSaveEntries(entries)
                                            e.audioPath?.let { File(it).delete() }
                                        }) { Text("Delete") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
